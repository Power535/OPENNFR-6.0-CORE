#ifndef _PLAYER_AUDIO_H_
#define _PLAYER_AUDIO_H_

int audio_register_stream_decoder(void);

#endif
