#ifndef _PLAYER_RM_H_
#define _PLAYER_RM_H_

int rm_register_stream_decoder(void);

#endif

