#ifndef _PLAYER_VIDEO_H_
#define _PLAYER_VIDEO_H_

int video_register_stream_decoder(void);

#endif
